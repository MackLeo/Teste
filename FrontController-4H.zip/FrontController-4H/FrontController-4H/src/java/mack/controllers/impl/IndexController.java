/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.controllers.impl;

import mack.controllers.AbstractController;

/**
 *
 * @author joaquim
 */
public class IndexController extends AbstractController {

    @Override
    public void execute() {
        this.setReturnPage("/index.jsp");
        this.getRequest().setAttribute("user", "Joaquim");
    }
    
}
