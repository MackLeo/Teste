/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.controllers.impl;

import java.util.ArrayList;
import java.util.List;
import mack.controllers.AbstractController;

/**
 *
 * @author joaquim
 */
public class ListController extends AbstractController {

    @Override
    public void execute() {
        List<String> users = new ArrayList();
        users.add("Joaquim");
        users.add("Davi");
        users.add("Zapa");
        users.add("Célia");
        users.add("Camila");
        users.add(request.getParameter("username"));
        this.setReturnPage("/index.jsp");
        this.getRequest().setAttribute("users", users);
    }
    
}
