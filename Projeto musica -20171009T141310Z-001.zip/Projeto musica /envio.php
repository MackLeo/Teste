<!DOCTYPE html>
<html>
<head>
    <title>Site 3</title>
    <meta charset="UTF-8"/>
     <link rel="stylesheet" type="text/css" href="css.css">
    </head>
    <body>
        <form action="comunicação.php" method="POST">
        <fieldset>
            <p>
            <label>Nome musica</label>
            <input type="text" name="nameMusica" id="nameMusica" required="required"/>
            </p>
        <p>
            <label>Nome Cantor</label>
            <input type="text" name="nameCantor" id="nameCantor" required="required"/>
            </p>
        <p>
            <label>Genero</label>
            <input type="text" name="genero" id="genero" required="required"/>
            </p>
              
        <p>
            <label>Genero</label>
            <input type="text" name="genero" id="genero" required="required"/>
            </p>  
            
  <label>Arquivo</label>
  <input type="file" name="arquivo" />
  
  <input type="submit" value="Enviar" />
            
            </fieldset>
        </form>   
        </body>
</html>