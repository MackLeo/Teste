<!DOCTYPE html>
<html>
<head>
    <title>Beta</title>
    <meta charset="UTF-8"/>
     <link rel="stylesheet" type="text/css" href="css.css">
    </head>
<header><h1>Free Music Share</h1>
<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#news">News</a></li>
  <li><a href="#contact">Contact</a></li>
  <li><a href="#about">About</a></li>
</ul>
</header>    

<section>
<p>Procure suas musicas favoritas:</p>
<div id="divBusca"><input id="txtBusca" type="text" placeholder="Buscar..." /></div>
</section>